from django.shortcuts import render, redirect
from .forms import UserForm, ProfilForm, QuestForm
from django.contrib.auth import authenticate, login, logout
from django.urls import reverse
from django.contrib.auth.models import User
from django.contrib import messages
from blog.models import Quest


def deconnexion(request):
    logout(request)
    return redirect(reverse(connexion))




def connexion(request):
    error = False

    if request.method == "POST":
        form = UserForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data["username"]
            password = form.cleaned_data["password"]
            user = authenticate(username=username, password=password)  # Nous vérifions si les données sont correctes
            if user:  # Si l'objet renvoyé n'est pas None
                login(request, user)  # nous connectons l'utilisateur
            else: # sinon une erreur sera affichée
                error = True
    else:
        form = UserForm()
    return render(request, 'blog/connexion.html',  { 'form':form })

def questionnaire(request):
    error = False
    if request.method == "POST":
        form = QuestForm(request.POST, instance=quest)
        if form.is_valid():
           
            form.save()
            temp = form.cleaned_data["temp"]
            toux = form.cleaned_data["toux"]
            gout = form.cleaned_data["gout"]
            douleur = form.cleaned_data["douleur"]
            diarrhee = form.cleaned_data["diarrhee"]
            fatigue = form.cleaned_data["fatigue"]
            aliment = form.cleaned_data["aliment"]
            souffle = form.cleaned_data["souffle"]
            age = form.cleaned_data["age"]
            taille = form.cleaned_data["taille"]
            poids = form.cleaned_data["poids"]
            coeur = form.cleaned_data["coeur"]
            diabete = form.cleaned_data["diabete"]
            cancer = form.cleaned_data["cancer"]
            respire = form.cleaned_data["respire"]
            dialyse = form.cleaned_data["dialyse"]
            foie = form.cleaned_data["foie"]
            enceinte = form.cleaned_data["enceinte"]
            immu = form.cleaned_data["immu"]
            tis = form.cleaned_data["tis"]
            codep = form.cleaned_data["codep"] 
            
            
        return render(request, 'blog/resultat.html',  { 'form':form })      
    else:
        form = QuestForm()
    return render(request, 'blog/questionnaire.html',  { 'form':form })    
      
    
def inscription(request):
    error = False

    if request.method == "POST":
        form = ProfilForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data["username"]
            email = form.cleaned_data["email"]
            password = form.cleaned_data["password"]
            verifpass = form.cleaned_data["verifpass"]
            
            new_user = User.objects.create_user(username=username, email=email, password=password)
            new_user.save()
            messages.success(request, 'Vous avez bien été enregistré!','alert alertsuccess')

           
        return render(request, 'blog/accueil.html',  { 'form':form })      
    else:
        form = ProfilForm()
    return render(request, 'blog/inscription.html',  { 'form':form })    
    
    
def test(request):
    
    return render(request, 'blog/test.html')

def resultat(request):
    
    return render(request, 'blog/resultat.html')
    
def accueil(request):
    
    return render(request, 'blog/accueil.html')