YN_CHOICES = (
    (1, ("Oui")),
    (2, ("Non"))
)

YNSP_CHOICES = (
    (1, ("Oui")),
    (2, ("Non")),
    (3, ("Ne sait pas"))
)

YNA_CHOICES = (
    (1, ("Oui")),
    (2, ("Non")),
    (3, ("Non applicable"))
)