from django import forms
from blog.choices import *
from blog.models import Quest

class UserForm(forms.Form):
    username = forms.CharField(max_length=30, label="Login")
    password = forms.CharField(widget=forms.PasswordInput, label="Mot de passe")
   
 
    def clean(self):
        cleaned_data = super(UserForm, self).clean()
        username = cleaned_data.get('username')
        password = cleaned_data.get('password')

        return cleaned_data



class ProfilForm(forms.Form):
    username = forms.CharField(max_length=30, label="Login")
    email = forms.EmailField(label="Votre adresse e-mail")
    password = forms.CharField(widget=forms.PasswordInput, label="Mot de passe")
    verifpass = forms.CharField(widget=forms.PasswordInput, label="Confirmez votre mot de passe")
    
   
 
    def clean(self):
        cleaned_data = super(ProfilForm, self).clean()
        username = cleaned_data.get('username')
        mail = cleaned_data.get('email')
        password = cleaned_data.get('password')
        verifpass = cleaned_data.get('verifpass')
        return cleaned_data    
        
    def clean_password(self):
        if self.data['password'] != self.data['verifpass']:
            raise forms.ValidationError('Les mots de passe ne correspondent pas')
        return self.data['password']   



class QuestForm(forms.ModelForm):
    temp = forms.FloatField(label="Ces dernières 48 heures, quelle a été votre température la plus élevée ?")
    toux = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner votre toux'}, choices = YN_CHOICES, label="Ces derniers jours, avez-vous une toux ou une augmentation de votre toux habituelle ?")
    gout = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner votre goût et ordorat'}, choices = YN_CHOICES, label="Ces derniers jours, avez-vous noté une forte diminution ou perte de votre goût ou de votre odorat ?")
    douleur = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner vos douleurs'}, choices = YN_CHOICES, label="Ces derniers jours, avez-vous eu un mal de gorge et/ou des douleurs musculaires et/ou des courbatures inhabituelles ?")
    diarrhee = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner vos selles'}, choices = YN_CHOICES, label="Ces dernières 24 heures, avez-vous de la diarrhée ? Avec au moins 3 selles molles.")
    fatigue = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner votre fatigue'}, choices = YN_CHOICES, label="Ces derniers jours, avez-vous une fatigue inhabituelle ?")
    aliment = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner votre alimentation'}, choices = YN_CHOICES, label="Depuis 24 heures ou plus, êtes-vous dans l'impossibilité de vous alimenter ou de boire ?")
    souffle = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner votre souffle'}, choices = YN_CHOICES, label="Ces dernières 24 heures, avez-vous noté un manque de souffle inhabituel lorsque vous parlez ou faites un petit effort ?")
    age = forms.IntegerField(error_messages={'required': 'Vous devez renseigner votre âge'}, label="Quel est votre âge ? Ceci, afin de calculer un facteur de risque spécifique.")
    taille = forms.IntegerField(error_messages={'required': 'Vous devez renseigner votre taille'}, label="Quel est votre taille ? Afin de calculer l’indice de masse corporelle qui est un facteur influençant le risque de complications de l’infection.")
    poids = forms.IntegerField(error_messages={'required': 'Vous devez renseigner votre poids'}, label="Quel est votre poids ? Afin de calculer l’indice de masse corporelle qui est un facteur influençant le risque de complications de l’infection.")
    coeur = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner vos problèmes cardiologique'}, choices = YNSP_CHOICES, label="Avez-vous de l’hypertension artérielle mal équilibrée ? Ou avez-vous une maladie cardiaque ou vasculaire ? Ou prenez vous un traitement à visée cardiologique ?")
    diabete = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner si vous êtes diabétique'}, choices = YN_CHOICES, label="Êtes-vous diabétique ?")
    cancer = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner si vous avez eu un cancer'}, choices = YN_CHOICES, label="Avez-vous ou avez-vous eu un cancer ces trois dernières années ?")
    respire = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner vos problèmes respiratoires'}, choices = YN_CHOICES, label="Avez-vous une maladie respiratoire ? Ou êtes-vous suivi par un pneumologue ?")
    dialyse = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner vos problèmes rénaux'}, choices = YN_CHOICES, label="Avez-vous une insuffisance rénale chronique dialysée ?")
    foie = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner vos problèmes de foie'}, choices = YN_CHOICES, label="Avez-vous une maladie chronique du foie ?")
    enceinte = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner si vous êtes enseinte'}, choices = YNA_CHOICES, label="Êtes-vous enceinte ?")
    immu = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner votre défense immunitaire'}, choices = YNSP_CHOICES, label="Avez-vous une maladie connue pour diminuer vos défenses immunitaires ?")
    tis = forms.ChoiceField(error_messages={'required': 'Vous devez renseigner un traitement immunosuppresseur'}, choices = YNSP_CHOICES, label="Prenez-vous un traitement immunosuppresseur ? C’est un traitement qui diminue vos défenses contre les infections. Voici quelques exemples : corticoïdes, méthotrexate, ciclosporine, tacrolimus, azathioprine, cyclophosphamide (liste non exhaustive).")
    codep = forms.IntegerField(error_messages={'required': 'Vous devez renseigner votre code postal'}, label="Quel est le code postal de votre résidence actuelle ? Cette information nous permet de réaliser un suivi épidémiologique")
   
    def clean(self):
        cleaned_data = super(ProfilForm, self).clean()
        temp = cleaned_data.get('temp')
        toux = cleaned_data.get('toux')
        gout = cleaned_data.get('gout')
        douleur = cleaned_data.get('douleur')
        diarrhee = cleaned_data.get('diarrhee')
        fatigue = cleaned_data.get('fatigue')
        aliment = cleaned_data.get('aliment')
        souffle = cleaned_data.get('souffle')
        age = cleaned_data.get('age')
        taille = cleaned_data.get('taille')
        poids = cleaned_data.get('poids')
        coeur = cleaned_data.get('coeur')
        respire = cleaned_data.get('')
        dialyse = cleaned_data.get('dialyse')
        foie = cleaned_data.get('foie')
        enceinte = cleaned_data.get('enceinte')
        immu = cleaned_data.get('immu')
        tis = cleaned_data.get('tis')
        codep = cleaned_data.get('codep')
        return cleaned_data
    
    class Meta:
        model = Quest
        fields = '__all__'
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
       
        