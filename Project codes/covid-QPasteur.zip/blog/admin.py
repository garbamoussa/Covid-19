from django.contrib import admin
from blog.models import Quest
from django.utils.text import Truncator

class QuestAdmin(admin.ModelAdmin):
   list_display   = ('temp', 'toux', 'gout', 'douleur', 'codep')
   """prepopulated_fields = {'slug': ('titre', ), }"""
   # Configuration du formulaire d'édition
   fieldsets = (
        # Fieldset 1 : meta-info (titre, auteur…)
       ('Général', {
            'classes': ['collapse', ],
            'fields': ('codep')
        }),
        # Fieldset 2 : contenu de l'article
        ('Contenu de l\'article', {
           'description': 'Le formulaire accepte les balises HTML. Utilisez-les à bon escient !',
           'fields': ('douleur', )
        }),
    )



admin.site.register(Quest)
