from django import forms


class UserForm(forms.Form):
    username = forms.CharField(max_length=30, label="Login")
    password = forms.CharField(widget=forms.PasswordInput, label="Mot de passe")
   
 
    def clean(self):
        cleaned_data = super(UserForm, self).clean()
        username = cleaned_data.get('username')
        password = cleaned_data.get('password')

        return cleaned_data



class ProfilForm(forms.Form):
    username = forms.CharField(max_length=30, label="Login")
    email = forms.EmailField(label="Votre adresse e-mail")
    password = forms.CharField(widget=forms.PasswordInput, label="Mot de passe")
    verifpass = forms.CharField(widget=forms.PasswordInput, label="Confirmez votre mot de passe")
    
   
 
    def clean(self):
        cleaned_data = super(ProfilForm, self).clean()
        username = cleaned_data.get('username')
        mail = cleaned_data.get('email')
        password = cleaned_data.get('password')
        verifpass = cleaned_data.get('verifpass')
        return cleaned_data    
        
    def clean_password(self):
        if self.data['password'] != self.data['verifpass']:
            raise forms.ValidationError('Les mots de passe ne correspondent pas')
        return self.data['password']   

    
        