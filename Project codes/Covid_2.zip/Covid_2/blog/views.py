from django.shortcuts import render, redirect
from .forms import UserForm, ProfilForm
from django.contrib.auth import authenticate, login, logout
from django.urls import reverse
from django.contrib.auth.models import User
from django.contrib import messages



def deconnexion(request):
    logout(request)
    return redirect(reverse(connexion))

def connexion(request):
    error = False

    if request.method == "POST":
        form = UserForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data["username"]
            password = form.cleaned_data["password"]
            user = authenticate(username=username, password=password)  # Nous vérifions si les données sont correctes
            if user:  # Si l'objet renvoyé n'est pas None
                login(request, user)  # nous connectons l'utilisateur
            else: # sinon une erreur sera affichée
                error = True
    else:
        form = UserForm()
    return render(request, 'blog/connexion.html',  { 'form':form })
    
    
def inscription(request):
    error = False

    if request.method == "POST":
        form = ProfilForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data["username"]
            email = form.cleaned_data["email"]
            password = form.cleaned_data["password"]
            verifpass = form.cleaned_data["verifpass"]
            
            new_user = User.objects.create_user(username=username, email=email, password=password)
            new_user.save()
            messages.success(request, 'Vous avez bien été enregistré!','alert alertsuccess')

           
        return render(request, 'blog/accueil.html',  { 'form':form })      
    else:
        form = ProfilForm()
    return render(request, 'blog/inscription.html',  { 'form':form })    
    
def accueil(request):
    
    return render(request, 'blog/accueil.html')