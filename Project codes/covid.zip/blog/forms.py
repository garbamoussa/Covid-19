from django import forms

class UserForm(forms.Form):
    username = forms.CharField(max_length=30, label="Login")
    password = forms.CharField(widget=forms.PasswordInput, label="Mot de passe")
   
 
    def clean(self):
        cleaned_data = super(UserForm, self).clean()
        username = cleaned_data.get('username')
        password = cleaned_data.get('password')

        return cleaned_data
        